import java.sql.*;

public class DataBaseP {

	public static void main(String[] args) {
		Connection con = null;
		Statement stmt = null;
		String url = "jdbc:mysql://localhost:55555/shopdb?serverTimezone=Asia/Seoul&useSSL=false";
		String user = "root";
		String passwd = "sungdls200o!";
		
		//JDBC 드라이버 연결 
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("드라이버 연결 오류");
			return;
		}
		/*
		//테이블 생성
		String createStr = "CREATE TABLE departments "+
							"(dname varchar(30) not null primary key, "+
							"director varchar(20) not null)";
		*/
		/*
		//테이블 레코드 삽입
		String insertStr = "INSERT INTO departments VALUES ";
		String recordStr[] = {
				insertStr + "('computer','pppp')",
				insertStr + "('art','aaaa')"
		};
		*/
		
		try {
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
		//	stmt.executeUpdate(createStr);
		//  테이블 생성 코드
		/*
		//레코드 삽입
			int i=0;
			while(i<recordStr.length) {
				stmt.executeUpdate(recordStr[i]);
				i++;
			}
		*/
			
			
		}catch(Exception e) {
			System.out.println(e.toString());
			return;
		}
		
		try {
			stmt.close();
			con.close();
		}catch(Exception e) {
			System.out.println(e.toString());
			return;
		}
		
		
	}
}
