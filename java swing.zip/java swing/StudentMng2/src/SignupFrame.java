import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;


public class SignupFrame extends JFrame{
	
	//	MainFrame
	//		ㄴnorthPanel
	//				-lb						
	//		ㄴwestPanel
	//				-idTextField
	//				-idStateLabel
	//				-pwTextField
	//				-pwCheckTextField
	//				-pwStateLabel
	//				-signupStateLabel
	//		ㄴeastPanel
	//				-idCheck
	//		ㄴsouthPenel
	//				-signUpButton
	
	
	JLabel lb = new JLabel("Sign-Up");								//
	JLabel signupStateLabel = new JLabel("                   ");	//회원가입 상황 알림		ex)비밀번호를 적어주세요, 아이디 중복 확인을 해주세요
	JLabel idLabel = new JLabel("ID");
	JLabel idStateLabel = new JLabel("                   ");		//아이디 중복 확인 ex)중복된 아이디가 있습니다. (Color : RED) @@@@@@@@@@@@@@
	JLabel pwLabel = new JLabel("PW");
	JLabel pwStateLabel = new JLabel("                   ");		//패스워드 중복 확인 ex)패스워드가 일치하지 않습니다. (Color : RED) @@@@@@@@@@@@@@
	JTextField idTextField = new JTextField(20);					//생성할 아이디 입력		무엇을 입력할지 가이드 추가 @@@@@@@@@@@@@@
	JTextField pwTextField = new JTextField(20);					//패스워드 입력			무엇을 입력할지 가이드 추가 @@@@@@@@@@@@@@
	JTextField pwCheckTextField = new JTextField(20);				//패스워드 재입력		무엇을 입력할지 가이드 추가 @@@@@@@@@@@@@@
	JButton idCheckButton = new JButton("CHECK");					//아이디 중복확인 버튼
	JButton signUpButton = new JButton("SIGN-UP");					//회원가입 버튼  -아이디 중복확인이 완료 되었을때만 회원가입
	JPanel northPanel = new JPanel();
	JPanel westPanel = new JPanel();
	JPanel eastPanel = new JPanel();
	JPanel southPanel = new JPanel();
	
	//SQL 접속을 위한 변수
	Connection con = null;
	Statement stmt = null;
	String url = "jdbc:mysql://localhost:55555/university?serverTimezone=Asia/Seoul&useSSL=false";
	String user = "root";
	String passwd = "sungdls200o!";
	
	
	//
	boolean idOverlapCheck = false;		 	//아이디 중복 검사 여부.  true면 검사완료 아이디 생성 가능 , false면 검사x 아이디 생성 불가
	boolean pwCheck = false;			//비밀번호 검사 여부. true면 검사완료, false면 검사x 
	
	
	SignupFrame(){
		JFrame mainSignUpFrame = new JFrame();
		
		setTitle("SIGN-UP FRAME");
		mainSignUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		//종료버튼 누를시 회원가입 창만 꺼짐 
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northPanel,BorderLayout.NORTH);
		c.add(westPanel,BorderLayout.WEST);
		c.add(eastPanel,BorderLayout.EAST);
		c.add(southPanel,BorderLayout.SOUTH);
		
		//northPanel 컴포넌트 추가 및 설정 
		northPanel.setPreferredSize(new Dimension(c.getHeight(),50));
		northPanel.add(lb);
		lb.setFont(new Font("Aria",Font.BOLD,30));
		
		//westPanel 컴포넌트 추가 및 설정
		westPanel.setPreferredSize(new Dimension(300,200));
		westPanel.setLayout(null);
		westPanel.add(idLabel);
		westPanel.add(idTextField);
		westPanel.add(idStateLabel);
		westPanel.add(pwLabel);
		westPanel.add(pwTextField);
		westPanel.add(pwCheckTextField);
		westPanel.add(pwStateLabel);
		westPanel.add(signupStateLabel);
		
		idTextField.setFont(new Font("Aria",Font.BOLD,15));
		pwTextField.setFont(new Font("Aria",Font.BOLD,15));
		pwCheckTextField.setFont(new Font("Aria",Font.BOLD,15));
		
		idLabel.setLocation(10,0);
		idTextField.setLocation(40,5);
		idStateLabel.setLocation(50,30);
		pwLabel.setLocation(10,50);
		pwTextField.setLocation(40,55);
		pwCheckTextField.setLocation(40,85);
		pwStateLabel.setLocation(50,110);
		signupStateLabel.setLocation(50,135);
		
		idLabel.setSize(30,30);
		idTextField.setSize(250,25);
		idStateLabel.setSize(200,25);
		pwLabel.setSize(30,30);
		pwTextField.setSize(250,25);
		pwCheckTextField.setSize(250,25);
		pwStateLabel.setSize(200,25);
		signupStateLabel.setSize(200,25);
		
		idTextField.setText("");
		pwTextField.setText("");
		
		//eastPanel 컴포넌트 추가 및 설정 
		eastPanel.add(idCheckButton);
		idCheckButton.addActionListener(new MyActionListener());
		idTextField.addFocusListener(new MyFocusListener());
		pwTextField.addFocusListener(new MyFocusListener());
		pwCheckTextField.addFocusListener(new MyFocusListener());
		
		//southPanel 컴포넌트 추가 및 설정 
		southPanel.setPreferredSize(new Dimension(c.getHeight(),50));
		southPanel.add(signUpButton);
		signUpButton.addActionListener(new MyActionListener());
		
		
		
		
		setSize(400,300);
		setVisible(true);
	}
	
	//아이디 중복확인 메소드
	public void IdCheck(){		//SQL 에서 중복된 아이디 탐색 하여 isOverlapCheck true,false 변환
		
		try {		//SQL connect
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("SQL Connect");//
			
		}catch(Exception e) {
			System.out.println(e.toString());//
		}
		
		String checkingId = idTextField.getText();		//아이디입력 필드에 입력된 아이디 저장
		System.out.println("입력된 아이디 : "+checkingId);//
		
		//SQL 탐색을 위한 쿼리 문자열
		String searchId = "";			//"SELECT password FROM user WHERE id='"+uid+"'";
		
		//아이디 탐색 쿼리 실행, 아이디 중복 검사
		try {
			searchId = "SELECT id FROM user WHERE id = '"+checkingId+"'";		
			ResultSet result = stmt.executeQuery(searchId);		//생성할 아이디가SQL에 있는지 탐색 
			
			
			if(result.next()) {			//아이디가 SQL에 존재한다면 stateLabel로 생성 불가능을 알림		//result.next() boolean값 반환
				System.out.println("SQL에서 가져온 값 : " + result.getString("id").toString());//
				
				idOverlapCheck = false;
				idStateLabel.setText("중복된 아이디가 이미 있습니다.");
				System.out.println("중복된 아이디 있음");
				
			}else {						//아이디가 SQL에 존재 하지 않으면 stateLabel로 생성 가능을 알림
				idOverlapCheck = true;
				idStateLabel.setText("생성가능한 아이디 입니다.");
				System.out.println("아이디 생성 가능");
			}
			
			result.close();
			stmt.close();
			con.close();
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		
		
	}
	
	//회원가입 실행 메소드
	public void SignUp() {
		try {		//SQL connect
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("SQL Connect");//
			
		}catch(Exception e) {
			System.out.println(e.toString());//
		}
		
		//SQL 인덱스 삽입을 위한 쿼리문자열
		String insertId = "";					//"INSERT INTO user VALUES ('" + id +"', '" + pass + "')";
		
		try {
			insertId = "INSERT INTO user VALUES ('" + idTextField.getText() + "', '" + pwTextField.getText() + "')";
			if(idOverlapCheck == true && pwCheck == true) {		//아이디 중복검사가 완료되었으면 SQL에 회원정보 인덱스 추가
				
				stmt.executeUpdate(insertId);
				System.out.println("회원가입 완료");
				System.out.println("아이디 : "+ idTextField.getText());
				System.out.println("비밀번호 : "+ pwTextField.getText());
				
				signupStateLabel.setText("아이디 생성 완료!! 창을닫고 로그인 해주세요");
				
			}else if(idOverlapCheck == false){
				signupStateLabel.setText("아이디 중복확인을 해주세요.");
			}else if(pwCheck == false){
				signupStateLabel.setText("비밀번호를 확인해 주세요.22");
			}else {
				System.out.println("ERROR1");
			}
			
			stmt.close();
			con.close();
			
			
			
		}catch(Exception e) {
			System.out.println(e.toString());
			signupStateLabel.setText("!!sign-up ERROR!!");
		}
		
	}
	
	class MyActionListener implements ActionListener{		//버튼 액션 리스너
		public void actionPerformed(ActionEvent e) {		
			if(e.getSource() == idCheckButton ) {					//SQL에서 중복되는 아이디가 있는지 검사
				signupStateLabel.setText("            ");
				if(idTextField.getText().indexOf(" ") != -1){		//아이디에 공백이 있거나 NULL값이 없을때만 중복검사
					idStateLabel.setText("공백이 포함되어 있습니다.");
					
				}else if(idTextField.getText().isEmpty()) {
					idStateLabel.setText("아이디를 입력해 주세요.");
					
				}else {		//아이디에 공백이 없거나, NULL값이 아닐떄만  아이디 중복검사 시행
					IdCheck();
				}
				//System.out.println("아이디 중복 검사 버튼");
				
			}else if(e.getSource() == signUpButton) {		//SQL에 새로운 아이디, 비밀번호 삽입
				SignUp();
				
				//System.out.println("회원가입 버튼");
			}
		}
	}
	class MyFocusListener implements FocusListener{		//비밀번호 텍스트 필드 포커스 리스너
		public void focusGained(FocusEvent e) {
			if(e.getSource() == idTextField) {		//아이디 텍스트 필드가 선택되면 아이디 중복 다시 검사해야함.
				idOverlapCheck = false;
				idStateLabel.setText("        ");
			}
		}		//
		public void focusLost(FocusEvent e) {			//필드가 포커스를 잃었을 때 비밀번호가 일치하는지 검사
			
			//비밀번호가 무조건 입력되어있여야한다.
			//입력된 비밀번호에 공백이 없고,입력된 비밀번호와 비밀번호 확인이 같을때 비밀번호 체크 true
			if(pwTextField.getText().isEmpty() == false) {
				System.out.println("비밀번호가 입력되었습니다.");
				if(pwCheckTextField.getText().equals(pwTextField.getText()) && pwTextField.getText().indexOf(" ") == -1) {		
					pwCheck = true;
					pwStateLabel.setText("비밀번호가 일치 합니다.");
					System.out.println("비밀번호 확인 완료");
				}else {
					pwCheck = false;
					pwStateLabel.setText("비밀번호를 확인해 주세요.");
					System.out.println("비밀번호 확인 x");
					
				}
			}else {
				System.out.println("비밀번호x");
			}
		}
	}
	
}
