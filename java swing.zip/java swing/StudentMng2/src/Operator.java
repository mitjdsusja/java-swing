

/*
 * 개발자 : 박성용
 * 개발기간 : 2022.10.31 ~ 2022.11.03
 * 개발목적 : GUI를 이용한 학생관리프로그램 개발(logIn 기능 + SQL 활용)
 */
public class Operator {

	public static void main(String[] args) {
		
//		LoginFrame lg = new LoginFrame();
		
		StudentManagerFrame sm =  new StudentManagerFrame();
	}

}
