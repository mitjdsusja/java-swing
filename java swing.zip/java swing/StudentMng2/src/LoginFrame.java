import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.event.*;

/*
 * 회원가입 구현
 * 		-아이디 중복체크 (o)
 * 		-중복이 아니면 아이디 생성가능 (o)
 * 		-비밀번호 중복 확인 (o)
 * 		-생성된 아이디 SQL user테이블에 삽입 (o)
 * 로그인 구현 
 * 		-아이디 SQL 에서 탐색 비밀번호 반환, 비밀번호가 같으면 로그인 다르면 Label로 알림 (o)
 * 		-로그인 성공시 학생관리매니저 창 띄움 (o)
 * 학생관리매니저 팝업
 * 		-학생관리매니저 (o)
 */

/*추가 구현 필요
 * -텍스트필드에 Default값으로 무엇을 입력해야하는지 가이드
 * -로그인 완료시 로그인화면 Close
 * -회원가입 화면이 활성화되면 로그인창 비활성화
 */

public class LoginFrame extends JFrame{
	
	// MainFrame
	//		ㄴnorthPanel	
	//			-lb				//
	//			-stateLabel		//로그인 상태 확인 ex)비밀번호가 틀릴시 비밀번호를 확인하시오.
	//		ㄴCenterPanel	(GridLayout)
	//			-idLabel			
	//			-idText			//ID를 입력하는 텍스트필드
	//			-pwLabel
	//			-passwdText		//PW를 입력하는 텍스트필드
	//		ㄴsouthPenel	(GridLayout)
	//			-logInButton	//로그인 버튼 - 아이디 패스워드가 일치한다면 학생관리프로그램 창이 생긴다.
	//			-signupButton	//회원가입 버튼 - 회원가입 팝업이 생긴다.
	
	JFrame mainLoginFrame = new JFrame();
	Container c = getContentPane();
	
	JLabel lb = new JLabel("Sign in to S_Manager");	
	JLabel stateLabel = new JLabel("                     ");	//로그인 상태 확인 ex)비밀번호가 틀릴시 비밀번호를 확인하시오. (Color : RED) @@@@@@@@@@@@@@
	JLabel idLabel = new JLabel("ID");
	JLabel pwLabel = new JLabel("PW");
	JButton loginButton = new JButton("Sign-In");
	JButton signUpButton = new JButton("Sign-Up");
	JPanel northPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	JPanel southPenel = new JPanel();
	JTextField idTextF = new JTextField(20);		//무엇을 입력할지 가이드 추가 (구현필요)
	JTextField pwTextF = new JTextField(20);		//무엇을 입력할지 가이드 추가 (구현필요)
	
	
	LoginFrame(){
		
		setTitle("P's StudentManager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//메인패널 설정
		c.setLayout(new BorderLayout());
		c.add(northPanel,BorderLayout.NORTH);
		c.add(centerPanel,BorderLayout.CENTER);
		c.add(southPenel,BorderLayout.SOUTH);
		
		//northPanel 컴포넌트 추가 및 설정
		northPanel.setPreferredSize(new Dimension(c.getHeight(),80));
		//northPanel.setBackground(Color.BLUE);
		northPanel.add(lb);
		lb.setLocation(200,50);
		lb.setFont(new Font("Aria",Font.BOLD,30));
		
		//centerPanel 컴포넌트 추가 및 설정
		centerPanel.add(stateLabel);
		stateLabel.setPreferredSize(new Dimension(350,30));
		stateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		centerPanel.add(idLabel);
		idLabel.setPreferredSize(new Dimension(20,30));
		centerPanel.add(idTextF);
		centerPanel.add(pwLabel);
		pwLabel.setPreferredSize(new Dimension(20,30));
		centerPanel.add(pwTextF);
		idTextF.setFont(new Font("Aria",Font.BOLD,15));
		pwTextF.setFont(new Font("Aria",Font.BOLD,15));
		
		//southPenel 컴포넌트 추가 및 설정
		southPenel.setLayout(new FlowLayout());
		southPenel.setPreferredSize(new Dimension(c.getHeight(),50));
		//southPenel.setBackground(Color.BLACK);
		southPenel.add(loginButton);
		southPenel.add(signUpButton);
		
		//Button 이벤트 리스너 삽입
		loginButton.addActionListener(new MyActionListener());
		signUpButton.addActionListener(new MyActionListener());
		
		setSize(350,300);
		setVisible(true);
	}
	
	
	
	class MyActionListener implements ActionListener{		//액션 이벤트 리스너 
		MyActionListener(){
			
		}
		public void actionPerformed(ActionEvent e) {		//버튼 액션
			
			if(e.getSource() == loginButton) {		//로그인 버튼을 눌렀을떄 이벤트
				//SQL에서 아이디에 맞는 패스워드를 가져온후 비교 -맞으면 학생관리매니저 창을 띄움 
				//									-틀리면 stateLabel 로 알림
				
				//텍스트 필드에서 아이디 가져옴 비밀번호 가져옴
				//가져온 값 LoginChecker 한테 넘겨줌 
				//true 값을 반환받으면 학생관리창 띄우기
				String id = idTextF.getText();
				String pw = pwTextF.getText();
				LoginChecker loginChecker = new LoginChecker(id,pw);
				if(loginChecker.loginCheck()) {	
					//학생관리창 생성
					StudentManagerFrame stm = new StudentManagerFrame();
					System.out.println("학생관리 창이 생성되었습니다.");
					
					//로그인창 사라짐 (구현 필요)
					
				}else {
					//아이디 혹은 비밀번호를 확인하라고 알림
					stateLabel.setText("아이디 혹은 비밀번호를 확인해 주세요.");
					System.out.println("아이디 혹은 비밀번호를 확인해 주세요.");
				}
				
//				System.out.println("로그인 버튼 눌림");
				
			}else if(e.getSource() == signUpButton) {		//회원가입 버튼을 눌렀을 떄 이벤트
				//회원가입 버튼을 눌렀을 떄 회원가입 팝업을 띄움
//				System.out.println("회원가입 버튼 눌림");
				new SignupFrame();
				
				//회원가입 창이 띄워지면 로그인창 포커스가 안잡히는 기능 (구현 필요)
			}
		}
		
	}
}

//로그인 확인 클래스
class LoginChecker {		//SQL 에 접속하여 아이디 비밀번호가 일치 하는 지 확인 
	String id;
	String pw;
	
	Connection con = null;
	Statement stmt = null;
	String url = "jdbc:mysql://localhost:55555/university?serverTimezone=Asia/Seoul&useSSL=false";
	String user = "root";
	String passwd = "sungdls200o!";
	
	LoginChecker(String _id, String _pw){		//체크할 아이디 비밀번호를 매개변수로 받음
		id = _id;
		pw = _pw;
		
		System.out.println("입력된 아이디 : " + id);
		System.out.println("입력된 비밀번호 : " + pw);
	}
	
	//로그인 가능한 계정 인지 확인 메소드
	//로그인 가능한 계정이면 true, 불가능한 계정이면 false반환
	boolean loginCheck() {
		boolean isCheck = false;
		
		try {		//SQL connect
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("SQL Connect");//
			
		}catch(Exception e) {
			System.out.println(e.toString());//
		}
		
		String searchQuery;			//"SELECT password FROM user WHERE id='"+uid+"'";
		//SQL에서 아이디 비밀번호 찾음		//"SELECT id FROM user WHERE id = '"+checkingId+"'";
		searchQuery = "SELECT password FROM user WHERE id = '" + id + "'";
		
		try {
			ResultSet result =stmt.executeQuery(searchQuery);//pw가져와서 비교
			if(result.next()) {		//가입된 아이디가 존재한다면
				String d_pw = result.getString("password").toString();//DB에서 해당아이디의 비밀번호 가져옴
				System.out.println("가입된 아이디의 비밀번호 : " + d_pw);
				if(d_pw.equals(pw)) {		//가입된 아이디가 있고, 비밀번호가 일치함
					isCheck = true;
				}
			}
			
			result.close();
			stmt.close();
			con.close();
			
		}catch(Exception e) {
			System.out.println(e.toString());
			System.out.println("로그인 확인 오류");
		}
		
		return isCheck;
	}
}