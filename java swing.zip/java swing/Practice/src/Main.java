import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		
		//new Practice();
//		new CTT();
		ArrayList<String> arr = new ArrayList<>();
		arr.add("123");
		arr.add("222");
		arr.add("333");
		
		Object[][] oo = new Object[3][3];
		oo[0] = arr.toArray();
		System.out.println(oo[0][0]);
		System.out.println(oo[0][1]);
		System.out.println(oo[0][2]);
	}

}