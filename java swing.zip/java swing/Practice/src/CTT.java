import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import java.util.ArrayList;

public class CTT extends JFrame{
	
	JPanel westPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	
	//콤보박스
	String [] fruits = { "apple","banana","kiwi"};
	JComboBox comboBox = new JComboBox(fruits);
	
	//테이블
	JTable table;
	DefaultTableModel tableModel;
	ArrayList<Object>[][] arr = new ArrayList[5][fruits.length];
	
	//트리
	JTree tree;
	DefaultMutableTreeNode root;
	DefaultTreeModel treeModel;
			
			
	CTT(){
		setTitle("aaaaaaaaaaaaaaaa");
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(westPanel,BorderLayout.WEST);
		c.add(centerPanel,BorderLayout.CENTER);
		
		//westPanel 배치
		westPanel.setBackground(Color.black);
		westPanel.setPreferredSize(new Dimension(150,c.getHeight()));
		westPanel.add(comboBox);
		comboBox.addActionListener(new MyActionListener());
		
		
		//centerPanel 배치
		centerPanel.setBackground(Color.blue);
		
		//westPanel
		root = new DefaultMutableTreeNode("학과");
		tree = new JTree(root);
		tree.setPreferredSize(new Dimension(160, 140));
		tree.addTreeSelectionListener(new MyTreeListener());
		
		for(int i = 0; i<fruits.length;i++ ) {
			DefaultMutableTreeNode node =  new DefaultMutableTreeNode(fruits[i]);
			
			root.add(node);
			
		}
		treeModel = (DefaultTreeModel)tree.getModel();
		treeModel.setRoot(root);
		westPanel.add(tree);
		
		//centerPanel
		tableModel = new DefaultTableModel(arr,fruits);
		table = new JTable(tableModel);
		JScrollPane sp = new JScrollPane(table);
		c.add(sp);
		
		setSize(500,300);
		setVisible(true);
	}
	class MyTreeListener implements TreeSelectionListener{
		public void valueChanged(TreeSelectionEvent e) {
			System.out.println(e.getPath());		//Print	[Root,Node]
		}
	}
	class MyActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == comboBox) {
				JComboBox cb = (JComboBox)e.getSource();
				System.out.println(cb.getSelectedItem());
			}
		}
	}
}
