/*
import java.io.*;
import java.util.StringTokenizer;
 
public class FileIO {
	public static void main(String[] args) {
		File dataFile = new File("C:/data.txt");		//파일 객체 생성
		File dataF = new File("C:/data2.txt");		//작성할 파일 객체 생성
		//  ./ 현재경로
		// ../ 상위폴더
		//   / 최상위폴더
		
		String readData; 		//읽은 데이터 임시 저장공간
		StringTokenizer st;		//토크나이저 변수
		
		
		try{
			BufferedReader br = new BufferedReader(new FileReader(dataFile));		//버퍼리더 파일 리더 생성
			BufferedWriter bw = new BufferedWriter(new FileWriter(dataF));
			while((readData = br.readLine()) != null ){		//파일에서 읽은 데이터가 공백이 아니면 계속 읽음 
						//readData 내용을 공백단위로 끊어 읽음
				String name = st.nextToken();		//끊은 내용을 name에 저장
				System.out.println("이름: " + name);
				
				bw.write(name +" ");		//파일에 작성
				
				String telNum = st.nextToken();		//위와 동일하게 공백까지 자름
				System.out.println(telNum);
				
				bw.write(telNum );
				bw.newLine();
				
				st = new StringTokenizer(telNum, "-");
				String telNumP1 = st.nextToken();
				String telNumP2 = st.nextToken();
				String telNumP3 = st.nextToken();
				System.out.println("전화번호: " + telNumP1 + "-" + telNumP2+ "-" + telNumP3  );
				
				
			}
			br.close();		//버퍼리더 메모리회수
			bw.close();
		}catch(IOException e){ 
			System.out.println(e.getMessage());
        }
	}
}
*/
