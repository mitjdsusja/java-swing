import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Practice extends JFrame {
	
	JButton b1 = new JButton("Button1");
	JLabel l2 = new JLabel("Label");
	JButton b3 = new JButton("Button3");
	JButton b4 = new JButton("Button4");
	JButton b5 = new JButton("Button5");
	JTextField t1 = new JTextField(20);
	JPanel pl = new JPanel();
	
	
	Practice(){
		setTitle("aaaa");		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		c.add(b1,BorderLayout.SOUTH);
		c.add(l2,BorderLayout.NORTH);
		c.add(pl,BorderLayout.CENTER);
		c.add(b4,BorderLayout.WEST);
		c.add(b5,BorderLayout.EAST);
		pl.add(t1);
		
		b1.addActionListener(new MyActionListener());
		b4.addActionListener(new MyActionListener());
		b5.addActionListener(new MyActionListener());
		t1.addActionListener(new MyActionListener());
		b5.addKeyListener(new MyKeyListener());
		b4.addFocusListener(new MyFocusListener());
		b1.addMouseMotionListener(new MyMouseMotionListener());
		
		
		setSize(500,500);
		setVisible(true);
		
	}
	class MyActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == t1) {
				l2.setText(t1.getText());
			}
			else {
				JButton b =(JButton)e.getSource();
				t1.setText(b.getText());
			}
		}
	}
	class MyItemListener implements ItemListener{
		public void itemStateChanged(ItemEvent e) {
			
		}
	}
	
	class MyKeyListener implements KeyListener{
		public void keyTyped(KeyEvent e) {
			Character n = e.getKeyChar();
			t1.setText(n.toString());
			
			System.out.println(n.toString());
			
		}
		public void keyPressed(KeyEvent e) {
			
		}
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	class MyFocusListener implements FocusListener{//focus : 클릭되어 선택되었을떄
		public void focusGained(FocusEvent e) {
			t1.setText("focusGained");
		}
		public void focusLost(FocusEvent e) {
			t1.setText("focusLost");
			
		}
	}
	class MyMouseMotionListener implements MouseMotionListener{
		public void mouseDragged (MouseEvent e) {
			
		}
		public void mouseMoved (MouseEvent e) {
			System.out.println(e.getSource());
		}
	}


}
