import java.io.*;
import java.sql.*;
import java.util.StringTokenizer;

//개발 목적 : SQL에 user테이블 생성 및 파일에서 불러온 데이터 삽입

public class DataInsert {
	
	//파일 불러오기
	File dataFile = new File("users.txt");
	
	//SQL 변수
	Connection con = null;
	Statement stmt = null;
	String url = "jdbc:mysql://localhost:55555/university?serverTimezone=Asia/Seoul&useSSL=false";
	String user = "root";
	String passwd = "sungdls200o!";

	public static void main(String[] args) {
		DataInsert di = new DataInsert();
		
	}
	
	DataInsert(){
		try {
			BufferedReader br = new BufferedReader(new FileReader(dataFile));
			String readData;
			StringTokenizer st;
			String id;
			String pass;
			String command;
			
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//CreateTable();
			
			while((readData = br.readLine()) != null) {
				st = new StringTokenizer(readData,"//");
				id = st.nextToken();
				pass = st.nextToken();
				command = "INSERT INTO user VALUES ('" + id +"', '" + pass + "')";
				stmt.executeUpdate(command);
				
			}
			
			stmt.close();
			con.close();
			
			
		}catch(Exception e) {		
		
			System.out.println(e.toString());
		}
	}
	
	//테이블 생성
	void CreateTable() {
		String ddl = "CREATE TABLE user "
					+"(id varchar(20) not null primary key,"
					+" password varchar(20) not null)";
		
		try {
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			stmt.executeUpdate(ddl);
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	

}
