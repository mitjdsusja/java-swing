import java.sql.*;

public class DataBaseP {

	public static void main(String[] args) {
		Connection con = null;
		Statement stmt = null;
		String url = "jdbc:mysql://localhost/practice?serverTimezone=Asia/seoul";
		String user = "root";
		String passward = "sungdls200o!";
		
		//JDBC 드라이버 연결 
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("드라이버 연결 오류");
			return;
		}
		
		String createStr = "CREATE TABLE departments "+
							"(dname varchar(30) not null primary key, "+
							"director varchar(20) not null";
		try {
			con = DriverManager.getConnection(url,user,passward);
			stmt = con.createStatement();
			stmt.executeUpdate(createStr);
			
			con.close();
			stmt.close();
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		
		
	}
}
