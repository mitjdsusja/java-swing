import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;


//개발자 : 박성용
//개발 기간 : 2022.10.06 ~ 2022.10.11
//개발 목적 : 효율적인 학생 관리를 위한 GUI기반 프로그램 개발

public class MainFrame extends JFrame {
	boolean isCheckUs = false;		//********체크박스 선택 확인 ********
	boolean isCheckGs = false;
	int ChoiceDepartment = -1;		//********시작시 학과선택x, 0,1,2,3,4 일때 각각  컴공,전자,기계,...********
	
	
	String[] departments = {"컴퓨터공학부","전자공학과", "기계공학과", "체육학과", "영문학과"};
	Object[][] students = {
			{"컴퓨터공학부", "1학년", "홍길동", "학부생", "111111"},
			{"컴퓨터공학부", "4학년", "김철수", "학부생", "123467"},
			{"컴퓨터공학부", "4학년", "이병헌", "학부생", "100011"},
			{"컴퓨터공학부", "2학년", "푸하하", "학부생", "145361"},
			{"컴퓨터공학부", "1학년", "하하하", "학부생", "111551"},
			{"컴퓨터공학부", "1학년", "강호동", "학부생", "123111"},
			{"컴퓨터공학부", "3학년", "이수근", "학부생", "165101"},
			{"컴퓨터공학부", "1학년", "서장훈", "학부생", "133411"},
			{"컴퓨터공학부", "1학년", "하하흐", "대학원생", "145532"},
			{"컴퓨터공학부", "2학년", "나마두", "대학원생", "163242"},
			{"컴퓨터공학부", "1학년", "라마단", "대학원생", "113213"},
			{"컴퓨터공학부", "2학년", "소리류", "대학원생", "141231"},
			{"컴퓨터공학부", "3학년", "이수간", "대학원생", "121231"},
			{"전자공학과", "1학년", "홍길동", "학부생", "111111"},
			{"전자공학과", "1학년", "김철수", "학부생", "123467"},
			{"전자공학과", "4학년", "이병헌", "학부생", "100011"},
			{"전자공학과", "4학년", "푸하하", "학부생", "145361"},
			{"전자공학과", "1학년", "하하하", "학부생", "111551"},
			{"전자공학과", "2학년", "강호동", "학부생", "123111"},
			{"전자공학과", "1학년", "이수근", "대학원생", "144235"},
			{"전자공학과", "2학년", "기기각", "대학원생", "155215"},
			{"전자공학과", "4학년", "조안지", "대학원생", "190097"},
			{"기계공학과", "1학년", "홍길동", "학부생", "116494"},
			{"기계공학과", "3학년", "서장훈", "학부생", "159817"},
			{"기계공학과", "2학년", "이수근", "학부생", "154893"},
			{"기계공학과", "1학년", "하하하", "학부생", "152346"},
			{"기계공학과", "4학년", "푸하하", "학부생", "187974"},
			{"기계공학과", "2학년", "김철수", "학부생", "199587"},
			{"기계공학과", "1학년", "김철수", "대학원생", "141526"},
			{"기계공학과", "4학년", "김철수", "학부생", "111847"},
			{"체육학과", "1학년", "홍길동", "학부생", "111425"},
			{"체육학과", "1학년", "서장훈", "학부생", "177845"},
			{"체육학과", "1학년", "이수근", "학부생", "195833"},
			{"체육학과", "2학년", "하하하", "학부생", "147851"},
			{"체육학과", "2학년", "푸하하", "학부생", "148571"},
			{"체육학과", "3학년", "김철수", "학부생", "199658"},
			{"체육학과", "3학년", "이병헌", "학부생", "132125"},
			{"체육학과", "3학년", "가나다", "대학원생", "114857"},
			{"영문학과", "3학년", "홍길동", "학부생", "118741"},
			{"영문학과", "3학년", "서장훈", "학부생", "165482"},
			{"영문학과", "4학년", "이수근", "대학원생", "144865"},
			{"영문학과", "2학년", "하하하", "학부생", "111952"},
			{"영문학과", "1학년", "푸하하", "대학원생", "154719"},
			{"영문학과", "1학년", "김철수", "학부생", "132541"},
			{"영문학과", "2학년", "이병헌", "학부생", "156849"},
			{"영문학과", "2학년", "가나다", "학부생", "178459"},
	};
	
	//공간제어용 컨테이너들.
	JPanel basePanel = new JPanel(new BorderLayout());
	JPanel westPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	//메뉴용
	JMenuBar mb = new JMenuBar();
	JMenu homeMenu = new JMenu("HOME");
	JMenuItem openMI = new JMenuItem("Open");
	JMenuItem newMI = new JMenuItem("New");
	JMenuItem exitMI = new JMenuItem("Exit");
	//웨스트패널상의 컴포넌트들....
	JLabel titleLabel = new JLabel("Select Student Type");
	JCheckBox usCheck = new JCheckBox("학부생");
	JCheckBox gsCheck = new JCheckBox("대학원생");
	JComboBox comboBox;
	JTree tree;
	DefaultMutableTreeNode root;
	DefaultTreeModel treeModel;
	//센터패널상의 컴포넌트들...
	JTable table;
	DefaultTableModel tableModel;
	String columNames[] = {"학과", "학년", "이름", "구분", "학번"};
	
	MainFrame(){
		setTitle("PSY's Student Management Program");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//메뉴추가
		homeMenu.add(openMI);
		homeMenu.add(newMI);
		homeMenu.add(exitMI);
		mb.add(homeMenu);
		setJMenuBar(mb);
		
		// 패널 추가 작업
		westPanel.setPreferredSize(new Dimension(160, basePanel.getHeight()));
		setContentPane(basePanel);
		basePanel.add(westPanel, BorderLayout.WEST);
		basePanel.add(centerPanel, BorderLayout.CENTER);
		westPanel.setLayout(new FlowLayout());
		
		//웨스트패널 컴포넌트 작업
		comboBox = new JComboBox(departments);
		comboBox.setPreferredSize(new Dimension(160, 20));
		titleLabel.setPreferredSize(new Dimension(160, 20));
		root = new DefaultMutableTreeNode("학과");
		tree = new JTree(root);
		tree.setPreferredSize(new Dimension(160, 140));
		
		usCheck.addItemListener(new MyItemListener());		//********이벤트리스너추가********
		gsCheck.addItemListener(new MyItemListener());
		comboBox.addActionListener(new MyActionListener());
		
		for(int i = 0; i<departments.length;i++ ) {
			DefaultMutableTreeNode node =  new DefaultMutableTreeNode(departments[i]);
			root.add(node);
			treeModel = (DefaultTreeModel)tree.getModel();
			treeModel.setRoot(root);
		}
		westPanel.add(titleLabel);
		westPanel.add(usCheck);
		westPanel.add(gsCheck);
		westPanel.add(comboBox);
		westPanel.add(tree);
		//센터패널 작업
		tableModel = new DefaultTableModel(students, columNames);
		table = new JTable(tableModel);
		JScrollPane sp = new JScrollPane(table);
		centerPanel.setLayout(new BorderLayout());
		centerPanel.add(sp, BorderLayout.CENTER);
		
		Filtering();		//********임시로 시작시 필터링 @@@@@   시작시 체크박스 체크되어있게 수정할 예정********
		
		setSize(900, 300);
		setVisible(true);
	}
	
	//********체크박스 이벤트 리스너********
	class MyItemListener implements ItemListener{		
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange() == ItemEvent.SELECTED) {		//체크박스 체크시 
				if(e.getItem() == usCheck) isCheckUs = true;
				else if(e.getItem() == gsCheck) isCheckGs = true;
			}
			else if (e.getStateChange() == ItemEvent.DESELECTED) {
				if(e.getItem() == usCheck) isCheckUs = false;
				else if(e.getItem() == gsCheck) isCheckGs = false;
			}
			Filtering();
		}
	}
	//********콤보박스 이벤트 리스너********
	class MyActionListener implements ActionListener{		
		public void actionPerformed(ActionEvent e) {
			JComboBox ccc = (JComboBox)e.getSource();
			ChoiceDepartment = ccc.getSelectedIndex();
			Filtering();
		}
	}
	
	//********학부생,대학원생, 학과 필터링 메소드********
	//학과 필터링 후, 학부생,대학원생 필터링
	//학부,대학원 둘다 체크시 학부,대학원생 둘다 출력
	//학부,대학원 둘중 하나 체크시 선택한 구분 출력
	//학부,대학원 아무것도 체크안할시 출력x 
	public void Filtering() {			
		TableRowSorter<TableModel> sorter  = new TableRowSorter<TableModel>(tableModel);		//http://cris.joongbu.ac.kr/course/2018-1/jcp/api/javax/swing/RowFilter.html
		ArrayList<RowFilter<Object, Object>> filters = new ArrayList<RowFilter<Object, Object>>(2);
		table.setRowSorter(sorter);
		RowFilter<TableModel, Object> rf = null;
		
		if(ChoiceDepartment != -1) {		//프로그램 실행 직후(ChoiceDepartment =-1)일때 학과 전체 출력 
			filters.add(RowFilter.regexFilter(departments[ChoiceDepartment], 0));		//학과 필터링
		}
		
		if(isCheckUs == true && isCheckGs == true) {		//체크박스 학부생, 대학원생 둘다 체크시 
			filters.add(RowFilter.regexFilter("", 3));		//학부생, 대학원생필터링
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == true && isCheckGs == false) {		//
			filters.add(RowFilter.regexFilter("학부생", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == false && isCheckGs == true) {		//
			filters.add(RowFilter.regexFilter("대학원생", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == false && isCheckGs == false) {		//
			filters.add(RowFilter.regexFilter("@@@@@@@", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		
	}
	public static void main(String[] args) {
		MainFrame mf =  new MainFrame();
	}
}