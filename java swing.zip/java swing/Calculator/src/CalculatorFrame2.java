import java.awt.*;

import java.awt.event.*;
import javax.swing.*;


//2019243096 박성용
// 개발 기간 2022.09.26 ~ 2022.10.05
// 개발 목적 : 사칙연산 및 Root 소수점 계산이 가능한 GUI Calculator개발



public class CalculatorFrame2 extends JFrame{
	JPanel topPanel = new JPanel();
	JPanel botPanel = new JPanel();
	JPanel buttonPanel1 = new JPanel();
	JPanel buttonPanel2 = new JPanel();
	JPanel buttonPanel3 = new JPanel();
	JTextField textField = new JTextField();
	JLabel textLabel = new JLabel();
	//Button 
	JButton clearButton = new JButton("Clear");
	JButton enterButton = new JButton("Enter");
	JButton button1 = new JButton("1");
	JButton button2 = new JButton("2");
	JButton button3 = new JButton("3");
	JButton button4 = new JButton("4");
	JButton button5 = new JButton("5");
	JButton button6 = new JButton("6");
	JButton button7 = new JButton("7");
	JButton button8 = new JButton("8");
	JButton button9 = new JButton("9");
	JButton buttonComma = new JButton(".");
	JButton buttonRoot = new JButton("root");
	JButton buttonPlus = new JButton("+");
	JButton buttonMinus = new JButton("-");
	JButton buttonMult = new JButton("*");
	JButton buttonDiv = new JButton("/");
	JButton button0 = new JButton("0");
	//label에 표시될 텍스트 처리 변수 (정수 연산)
	String[] arr = new String[100];
	int count =0;		//배열에 들어간 String 개수
	int operCount =0 ;		//배열에 들어간 연산자 개수 
	boolean useComma = false;		//기호가 사용됐는지 확인 (부적절한 위치임을 판정)
	boolean useOper = true;
	String printText="";		//Label에 출력될 텍스트
	String temp="";			//연산자 까지의 printText 임시저장 변수		
	
	
	CalculatorFrame2(){
		setTitle("PSY's Calculator");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(topPanel,BorderLayout.NORTH);
		c.add(botPanel,BorderLayout.CENTER);
		
		//c
		//ㄴtopPanel
		//	ㄴtextLabel
		//ㄴbottomPanel
		//	ㄴButtonPanel1
		//		ㄴclearButton
		//	ㄴButtonPanel2
		//		ㄴButton(0~9),button(plus ~	root)
		//	ㄴButtonPanel3
		//		ㄴEnterButton
		
		//topPanel 컴포넌트
		topPanel.setLayout(null);
		textLabel.setBackground(Color.WHITE);
		textLabel.setOpaque(true);
		textLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		textLabel.setFont(new Font("굴림", Font.BOLD, 40));		
		topPanel.add(textLabel);
		topPanel.setPreferredSize(new Dimension(c.getWidth(),70));
		textLabel.setBounds(10,10,280,50);
		//textLabel.setFont(new Font("굴림", Font.BOLD, 40));
		
		//bottomPanel 컴포넌트  
		botPanel.setLayout(new BorderLayout());
		buttonPanel1.setLayout(null);
		buttonPanel2.setLayout(new GridLayout(4,4,10,5));
		buttonPanel3.setLayout(null);
		botPanel.add(buttonPanel1,BorderLayout.NORTH);
		botPanel.add(buttonPanel2,BorderLayout.CENTER);
		botPanel.add(buttonPanel3,BorderLayout.SOUTH);
		buttonPanel1.add(clearButton);		
		buttonPanel2.add(button1);buttonPanel2.add(button2);buttonPanel2.add(button3);buttonPanel2.add(buttonPlus);
		buttonPanel2.add(button4);buttonPanel2.add(button5);buttonPanel2.add(button6);buttonPanel2.add(buttonMinus);
		buttonPanel2.add(button7);buttonPanel2.add(button8);buttonPanel2.add(button9);buttonPanel2.add(buttonMult);
		buttonPanel2.add(button0);buttonPanel2.add(buttonComma);buttonPanel2.add(buttonRoot);buttonPanel2.add(buttonDiv);
		buttonPanel3.add(enterButton);
		buttonPanel1.setPreferredSize(new Dimension(50,60));
		//숫자패드 배치 명령어 들어갈 자리 @@@@@@@@@@@
		//구현x
		buttonPanel3.setPreferredSize(new Dimension(50,60));
		clearButton.setBounds(10, 5, 280, 50);
		enterButton.setBounds(10, 5, 280, 50);
		
		SetEventListener();		//이벤트리스너 삽입함수
		
		
		setSize(315,370);
		setVisible(true);
	}
	
	
	
	//버튼 숫자 입력으로 String 배열에 숫자 저장
	//연산자 버튼 클릭시 연산자 저장 
	//버튼 숫자 입력으로 String 배열에 숫자 저장
	// 				...
	//ROOT : String 내부 현재 저장된 값을 제곱근 형태로 변환
	//ENTER : String 배열 내부값 Double 형태로 변환후 사칙연산
	//Clear : 모든 변수 초기화
	//-이미 수가 소수 이거나 나올수 없는 위치이면 "." 사용 불가
	//-연산자 중복사용, 나올수 없는 위치이면 사용 불가
	private class ButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//버튼 실행내용 switch
			JButton b = (JButton)e.getSource();
			double n;
			switch(b.getText()) {
			case "."://소수점 계산을 위해 "."도 숫자와 같은 배열에 입력
				if(useComma == true || arr[count]==null)	break;		//소수점 중복사용 및 사용불가능한 위치 일때 소수점 사용불가능
				else useComma = true;
			case "1"://누른 버튼에 맞는 숫자 입력
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
			case "0": 	
				if(arr[count]==null)arr[count]="";		//null값을 공백으로 비움
				printText += b.getText();		//Label 에 출력될 텍스트
				arr[count] += b.getText();		//배열에 스트링 저장
				textLabel.setText(printText);
				System.out.println(arr[count]);
				break;
				
			case "root":		//제곱근 연산
				n = Math.sqrt(Double.parseDouble(arr[count]));		
				n = Math.round(n*100)/100.0;	//		반올림하여 소수 둘째자리까지 나타냄	
				arr[count]=Double.toString(n);
				if(operCount == 0) {		//첫째항 이라면
					textLabel.setText(arr[0]);
					printText = arr[0];
				}
				else {			//첫째항이 아니라면
					textLabel.setText(temp + arr[count]);
					printText = temp + arr[0];
				}
				useComma = true;
				break;
				
			case "+":
			case "-":
			case "*":
			case "/":
				//연산자 중복사용 및 사용불가능한 위치 일때 연산자 사용불가능@@@@@ 
				if(useOper == true && arr[count] == null)break;
				else useOper = true;
				count++;
				arr[count] = b.getText();		//배열에 연산자 입력
				System.out.println(arr[count]);
				count++;
				operCount++;
				printText += b.getText();
				textLabel.setText(printText);
				temp = printText;
				useComma = false;
			break;
			
			case "Enter":		//Enter 누를시 사칙 연산
				n = Double.parseDouble(arr[0]);
				for(int i = 0 ; i< count ; i+=2) {
					if(arr[i+1]=="+") {
						n += Double.parseDouble(arr[i+2]);
					}
					else if(arr[i+1]=="-") {
						n -= Double.parseDouble(arr[i+2]);
					}
					else if (arr[i+1]=="*") {
						n *= Double.parseDouble(arr[i+2]);
					}
					else if(arr[i+1]=="/") {
						n /= Double.parseDouble(arr[i+2]);
					}
					useComma = true;
					useOper = false;
				}
				
				for(int i=1;i<count+1;i++) {		//enter후 결과값을 바로 사용가능하게 나머지 배열 초기화 후 결과값 저장
					arr[i]=null;
				}
				n = Math.round(n*100)/100.0;	//		반올림하여 소수 둘째자리까지 나타냄	
				arr[0]=Double.toString(n);
				operCount=0;
				printText = Double.toString(n);		//결과값 출력
				textLabel.setText(printText);
				break;
				
			case "Clear":		//모든 변수 초기화
				for(int i=0;i<count;i++) {
					arr[i]=null;
				}
				count=0; operCount =0;printText="";textLabel.setText(printText);
				useOper = false;
				useComma = false;
				break;
			}
		}
	}
	
	void SetEventListener() {
		ButtonActionListener btnActListener = new ButtonActionListener();
		button1.addActionListener(btnActListener);
		button2.addActionListener(btnActListener);
		button3.addActionListener(btnActListener);
		button4.addActionListener(btnActListener);
		button5.addActionListener(btnActListener);
		button6.addActionListener(btnActListener);
		button7.addActionListener(btnActListener);
		button8.addActionListener(btnActListener);
		button9.addActionListener(btnActListener);
		button0.addActionListener(btnActListener);
		buttonComma.addActionListener(btnActListener);
		buttonRoot.addActionListener(btnActListener);
		buttonPlus.addActionListener(btnActListener);
		buttonMinus.addActionListener(btnActListener);
		buttonMult.addActionListener(btnActListener);
		buttonDiv.addActionListener(btnActListener);
		enterButton.addActionListener(btnActListener);
		clearButton.addActionListener(btnActListener);
		
	}
	
}
