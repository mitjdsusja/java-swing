import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class CalculatorFrame extends JFrame {
	int tHor = 30;	//TextFieldSize
	int tVer = 40;
	int fHor = 300;	// FrameSize
	int fVer = 350;
	
	JPanel topPanel = new JPanel();			//텍스트패널
	JPanel botPanel = new JPanel();
	JPanel inputButtonPanel = new JPanel();			//숫자패널
	JPanel buttonPanel = new JPanel();			//C버튼패널
	JTextField calResultField = new JTextField("                 ");
	JButton clearButton = new JButton("Clear");
	JButton enterButton = new JButton("Enter");
	JButton button1 = new JButton("1");
	JButton button2 = new JButton("2");
	JButton button3 = new JButton("3");
	JButton button4 = new JButton("4");
	JButton button5 = new JButton("5");
	JButton button6 = new JButton("6");
	JButton button7 = new JButton("7");
	JButton button8 = new JButton("8");
	JButton button9 = new JButton("9");
	JButton buttonComma = new JButton(".");
	JButton buttonRoot = new JButton("root");
	JButton buttonSlash = new JButton("/");
	JButton buttonMul = new JButton("*");
	JButton buttonMi = new JButton("-");
	JButton buttonPlus = new JButton("+");
	JButton button0 = new JButton("0");
	
	
	
	CalculatorFrame(){
		
		setTitle("Calculator");			//Create MainFrame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setBackground(Color.CYAN);
		
		
		topPanel.setBackground(Color.darkGray);
		topPanel.add(calResultField);
		botPanel.setBackground(Color.green);
		botPanel.add(buttonPanel);
		inputButtonPanel.setLayout(new GridLayout(4,4,10,10));
		inputButtonPanel.setBackground(Color.darkGray);
		inputButtonPanel.add(button1);inputButtonPanel.add(button2);inputButtonPanel.add(button3);inputButtonPanel.add(buttonPlus);
		inputButtonPanel.add(button4);inputButtonPanel.add(button5);inputButtonPanel.add(button6);inputButtonPanel.add(buttonMi);
		inputButtonPanel.add(button7);inputButtonPanel.add(button8);inputButtonPanel.add(button9);inputButtonPanel.add(buttonMul);
		inputButtonPanel.add(button0);inputButtonPanel.add(buttonComma);inputButtonPanel.add(buttonRoot);inputButtonPanel.add(buttonSlash);
		
		
		buttonPanel.setLayout(new BorderLayout());
		buttonPanel.add(clearButton,BorderLayout.NORTH);			//SubPanel "CLEAR"
		buttonPanel.add(inputButtonPanel,BorderLayout.CENTER);		//subPanel "NumberPad"
		buttonPanel.add(enterButton,BorderLayout.SOUTH);			//SubPanel "ENTER"
		
		calResultField.setHorizontalAlignment(SwingConstants.RIGHT);		//텍스트필드설정
		calResultField.setFont(new Font("굴림", Font.BOLD, 40));
		calResultField.setBackground(Color.WHITE);

		c.setLayout(new BorderLayout());			//컨테이너 설정
		c.add(topPanel,BorderLayout.NORTH);
		c.add(botPanel,BorderLayout.CENTER);
		
		
		setSize(fHor,fVer);
		setVisible(true);
	}
	
	
}
