import java.awt.*;

import java.awt.event.*;
import javax.swing.*;

//버튼 리스너 넣고 기능구현

public class test1 extends JFrame{
	JPanel topPanel = new JPanel();
	JPanel botPanel = new JPanel();
	JPanel buttonPanel1 = new JPanel();
	JPanel buttonPanel2 = new JPanel();
	JPanel buttonPanel3 = new JPanel();
	JTextField textField = new JTextField();
	JLabel textLabel = new JLabel();
	//Button 
	JButton clearButton = new JButton("Clear");
	JButton enterButton = new JButton("Enter");
	JButton button1 = new JButton("1");
	JButton button2 = new JButton("2");
	JButton button3 = new JButton("3");
	JButton button4 = new JButton("4");
	JButton button5 = new JButton("5");
	JButton button6 = new JButton("6");
	JButton button7 = new JButton("7");
	JButton button8 = new JButton("8");
	JButton button9 = new JButton("9");
	JButton buttonComma = new JButton(".");
	JButton buttonRoot = new JButton("root");
	JButton buttonPlus = new JButton("+");
	JButton buttonMinus = new JButton("-");
	JButton buttonMult = new JButton("*");
	JButton buttonDiv = new JButton("/");
	JButton button0 = new JButton("0");
	//label에 표시될 텍스트 처리 변수 
	int[] arr = new int[100];	
	int count =0;
	int num;
	int resultInt =0;
	double resultF =0;
	int operPos =0;
	int commaPos =0;
	int operStat=0;		// operStat = 4,3,2,1 이면 +,-,*,/
	String printText="";
	
	
	test1(){
		setTitle("Calculator");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(topPanel,BorderLayout.NORTH);
		c.add(botPanel,BorderLayout.CENTER);
		
		//topPanel 컴포넌트
		topPanel.setLayout(null);
		textLabel.setBackground(Color.WHITE);
		textLabel.setOpaque(true);
		//text 우측 정렬 코드 자리 @@@@@@@@@@@@@
		topPanel.add(textLabel);
		topPanel.setPreferredSize(new Dimension(c.getWidth(),70));
		textLabel.setBounds(10,10,280,50);
		//textLabel.setFont(new Font("굴림", Font.BOLD, 40));
		
		//bottomPanel 컴포넌트 
		botPanel.setLayout(new BorderLayout());
		buttonPanel1.setLayout(null);
		buttonPanel2.setLayout(new GridLayout(4,4,10,5));
		buttonPanel3.setLayout(null);
		botPanel.add(buttonPanel1,BorderLayout.NORTH);
		botPanel.add(buttonPanel2,BorderLayout.CENTER);
		botPanel.add(buttonPanel3,BorderLayout.SOUTH);
		buttonPanel1.add(clearButton);		
		buttonPanel2.add(button1);buttonPanel2.add(button2);buttonPanel2.add(button3);buttonPanel2.add(buttonPlus);
		buttonPanel2.add(button4);buttonPanel2.add(button5);buttonPanel2.add(button6);buttonPanel2.add(buttonMinus);
		buttonPanel2.add(button7);buttonPanel2.add(button8);buttonPanel2.add(button9);buttonPanel2.add(buttonMult);
		buttonPanel2.add(button0);buttonPanel2.add(buttonComma);buttonPanel2.add(buttonRoot);buttonPanel2.add(buttonDiv);
		buttonPanel3.add(enterButton);
		buttonPanel1.setPreferredSize(new Dimension(50,60));
		//숫자패드 배치 코드 들어갈 자리 @@@@@@@@@@@
		buttonPanel3.setPreferredSize(new Dimension(50,60));
		clearButton.setBounds(10, 5, 280, 50);
		enterButton.setBounds(10, 5, 280, 50);
		
		SetEventListener();
		//SetObjectColor();
		
		
		setSize(315,370);
		setVisible(true);
	}
	
	private class ButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//버튼 실행내용 switch
			JButton b = (JButton)e.getSource();
			switch(b.getText()) {
			case "1":
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
			case "0": 		//누른 버튼에 맞는 숫자 입력
			arr[count] = Integer.parseInt(b.getText());count++;
			printText += b.getText();
			textLabel.setText(printText);
				break;
			case "root":		//제곱근 연산
				resultF = Math.sqrt(ConvertInt(arr,0,count));
				System.out.println(resultF);
				textLabel.setText(String.valueOf(resultF));
				break;
			case "+":operStat++;
			case "-":operStat++;
			case "*":operStat++;
			case "/":operStat++;
			printText += b.getText();
			textLabel.setText(printText);
			operPos =count;
			break;
			case ".":
				printText += b.getText();
				textLabel.setText(printText);
				commaPos =count;
				break;
			case "Enter":		//Enter 누를시 사칙 연산
				if(operStat == 4) {			//더하기 연산
					resultInt = ConvertInt(arr,0,operPos) + ConvertInt(arr,operPos,count);
					System.out.println(ConvertInt(arr,0,operPos) + "+"+ConvertInt(arr,operPos,count));		//
					textLabel.setText(Integer.toString(resultInt));
				}else if(operStat ==3) {		//빼기 연산
					resultInt = ConvertInt(arr,0,operPos) - ConvertInt(arr,operPos,count);
					System.out.println(ConvertInt(arr,0,operPos) + "-"+ConvertInt(arr,operPos,count));		//
					textLabel.setText(Integer.toString(resultInt));
				}else if(operStat ==2) {		//곱하기 연산
					resultInt = ConvertInt(arr,0,operPos) * ConvertInt(arr,operPos,count);
					System.out.println(ConvertInt(arr,0,operPos) + "*"+ConvertInt(arr,operPos,count));		//
					textLabel.setText(Integer.toString(resultInt));
				}else if(operStat ==1) {		//나누기 연산
					double d =	ConvertInt(arr,0,operPos);
					resultF = d / ConvertInt(arr,operPos,count);
					System.out.println(ConvertInt(arr,0,operPos) + "/"+ConvertInt(arr,operPos,count));		//
					textLabel.setText(String.valueOf(resultF));
				}
				break;
			case "Clear":		//초기화
				count=0;operStat=0;printText="";textLabel.setText(printText);
				break;
			}
		}
	}
	
	void SetEventListener() {
		ButtonActionListener btnActListener = new ButtonActionListener();
		button1.addActionListener(btnActListener);
		button2.addActionListener(btnActListener);
		button3.addActionListener(btnActListener);
		button4.addActionListener(btnActListener);
		button5.addActionListener(btnActListener);
		button6.addActionListener(btnActListener);
		button7.addActionListener(btnActListener);
		button8.addActionListener(btnActListener);
		button9.addActionListener(btnActListener);
		button0.addActionListener(btnActListener);
		buttonComma.addActionListener(btnActListener);
		buttonRoot.addActionListener(btnActListener);
		buttonPlus.addActionListener(btnActListener);
		buttonMinus.addActionListener(btnActListener);
		buttonMult.addActionListener(btnActListener);
		buttonDiv.addActionListener(btnActListener);
		enterButton.addActionListener(btnActListener);
		clearButton.addActionListener(btnActListener);
		
	}
	void SetObjectColor() {			//패널색상설정
		topPanel.setBackground(Color.black);
		botPanel.setBackground(Color.blue);
		buttonPanel1.setBackground(Color.cyan);
		buttonPanel2.setBackground(Color.DARK_GRAY);
		buttonPanel3.setBackground(Color.gray);
	}
	int ConvertInt( int[] arr,int j,int k) { 		//Int배열 Int로 변환   ex) {1,0,3} => 10
		int result =0;
		int temp = 0;
		
		for(int i = j;i < k ; i++) {
			temp = arr[i];
			for(int h = 0 ; h < k-i-1 ; h++) { // 10거듭제곱 연산
				temp = temp * 10;
			}
			result += temp;
		}
		return result;
	}
	
}