
public class Operator {

	public static void main(String[] args) {
		//new CalculatorFrame();
		new CalculatorFrame2();
	}

}
