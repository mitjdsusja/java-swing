import java.io.*;
import java.io.IOException;
import java.net.*;
import java.net.SocketException;
import java.util.ArrayList;


public class Server {		//MainThread 
	ServerSocket ss = null;
	ArrayList<ConnectedClient> clients = new ArrayList<ConnectedClient>();
	
	
	public static void main(String[] args) {
		Server server = new Server();
		try {
			server.ss = new ServerSocket(12345);
			System.out.println("Server > Server Socket is Create");
			while(true) {
				Socket socket = server.ss.accept();
				ConnectedClient c = new ConnectedClient(socket, server);
				server.clients.add(c);
				c.start();
				
			}
			
		}catch(SocketException e) {
			System.out.println("Server > 서버종료");
		}catch(IOException e) {
			System.out.println("Server > 서버종료");
		}

	}
	

}
class ConnectedClient extends Thread{		//
	Socket socket;
	OutputStream outStream;		//Output 채널
	DataOutputStream dataOutStream;		//Output Data
	InputStream inStream;
	DataInputStream dataInStream;
	String msg;
	String uName;
	Server server;
	
	ConnectedClient(Socket _s, Server _ss){
		this.socket = _s;
		this.server = _ss;
	}
	public void run() {
		try {
			System.out.println("Server > " + this.socket.toString());//클라이 언트의 IP넘버 포트 주소 를 가지 고 있음
			outStream = this.socket.getOutputStream();
			dataOutStream = new DataOutputStream(outStream);
			inStream = this.socket.getInputStream();
			dataInStream = new DataInputStream(inStream);
			
			dataOutStream.writeUTF("welcome to this server11");
			
			uName = dataInStream.readUTF();		//유저 이름 받기
			
			while(true) {
				msg = dataInStream.readUTF();
				System.out.println("Server > " + this.uName + ": " + msg);
				
				
				for(int i=0 ; i< server.clients.size(); i++) {	//모든 Client 에게 메세지 보냄
					if(!(uName.equals(server.clients.get(i).uName))) {
						outStream = server.clients.get(i).socket.getOutputStream();
						dataOutStream = new DataOutputStream(outStream);
						dataOutStream.writeUTF(uName + "send : " + msg);
					}
				}
			}
			
		}catch(IOException e) {
			System.out.println("Server > 입출력 예외 발생");
		}
		
	}
}
