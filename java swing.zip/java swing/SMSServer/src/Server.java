import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Server {
	ServerSocket ss = null;
	ArrayList<ConnectedClient> clients = new ArrayList<ConnectedClient>();
	LoginChecker lc = null;

	public static void main(String[] args) {
		Server server = new Server();
		server.lc = new LoginChecker();
		
		try {
			server.ss = new ServerSocket(20000);
			System.out.println("Server > Server Socket is Create....");
			while(true) {
				Socket socket = server.ss.accept();
				ConnectedClient c = new ConnectedClient(socket, server);
				server.clients.add(c);
				c.start();
				
			}
			
		}catch(SocketException e) {
			System.out.println("Server > 서버종료");
		}catch(IOException e) {
			System.out.println("Server > 서버종료");
		}

	}
	
	
	
}


class ConnectedClient extends Thread{		//
	Socket socket;
	OutputStream outStream;		//Output 채널
	DataOutputStream dataOutStream;		//Output Data
	InputStream inStream;
	DataInputStream dataInStream;
	
	Server server;		//서버 참조
	
	final String loginTag = "LOGIN";
//	final String quaryTag = "QUARY";
	
	ConnectedClient(Socket _s, Server _ss){
		this.socket = _s;
		this.server = _ss;
	}
	
	public void run() {
		System.out.println("Server > " + this.socket.toString() + "에서의 접속이 연결되었습니다.");
		
		try {
			
			outStream = this.socket.getOutputStream();
			dataOutStream = new DataOutputStream(outStream);
			inStream = this.socket.getInputStream();
			dataInStream = new DataInputStream(inStream);
			String msg = null;
			
			while(true) {
				msg = dataInStream.readUTF();
				StringTokenizer stk = new StringTokenizer(msg,"//");		//아이디 패스워드를 클라이언트로부터 받음
				if(stk.nextToken().equals(loginTag)) {		// 입력 : LOGIN//ID//PW
					String id = stk.nextToken();
					String pw = stk.nextToken();
					if(server.lc.check(id,pass)) {		//로그인체크
						dataOutStream.writeUTF("LOGIN_OK");
					}
					else {
						dataOutStream.writeUTF("LOGIN_FAIL");
					}
				}
				
				
			}
			
		}catch(IOException e) {
			
		}
		
		
	}

}
class LoginChecker{			//1. users.txt 파일에서 서버가 관리하는 유저 정보 읽어오기 2. 읽어온 유저정보를 객체화 하여 관리하기 3. 로그인 확인 서비스
	File dataFile = new File("users.txt");
	String readData;
	StringTokenizer st;
	ArrayList<User> userInfor = new ArrayList<User>();
	
	LoginChecker(){
		try {
			BufferedReader br = new BufferedReader(new FileReader(dataFile));
			while((readData = br.readLine()) != null) {		//읽은 데이터가 있으면 반복해서 읽어들임
				st = new StringTokenizer(readData,"//");
				String userID = st.nextToken();
				String userPW = st.nextToken();
				User user = new User(userID,userPW);
				userInfor.add(user);
			}
			br.close();
			
		}catch(Exception e) {
			
		}
	}
	
	boolean check(String _id, String _pw) {
		boolean flag = false;
		for(int i=0; i<userInfor.size() ; i++) {
			if(userInfor.get(i).id.equals(_id) && userInfor.get(i).pw.equals(_pw)) {		//가입된 유저라면 로그인
				flag = true;
				
			}
		}
		
		return flag;
	}
}

class User{		//가입된 유저 객체화
	String id;
	String pw;
	
	User(String _id, String _pw){
		id = _id;
		pw = _pw;
	}
}
