import java.util.Scanner;

public class InputManager {

	Scanner scn = new Scanner(System.in); 
	
	int getInt() { //정수 입력
		int i = 0 ;
		i = scn.nextInt();
		return i;
	}
	double getDouble() { // 실수 입력
		double i = 0 ;
		i = scn.nextDouble();
		return i;
	}
	
}
