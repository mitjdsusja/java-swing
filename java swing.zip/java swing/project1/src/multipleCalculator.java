
public class multipleCalculator {
	int maximum = 500;
	int n = 0;  // 입력한 정수 저장할 변수
	
	void insertInt() { // 정수 입력
		InputManager mg = new InputManager();
		int a;
		
		while(true) {  // 0~10 값을 넣으면 저장
			System.out.print("정수를 입력하시오 : ");
			a = mg.getInt();
			
			if ( 0 < a && a <= 10) {
				n = a;
				break;
				
			}else {
				System.out.println("1 에서 10 까지의 정수를 입력하시오 ");
			}
		}
	}
	
	void mCalculate() {  // 배수 계산, 출력
		
		for (int i = 0 ; i <= maximum ; i++) {
			
			if( i % n == 0 && i != 0) {
				for(int j=0; j<5;j++) {
					System.out.print(i);
					System.out.print(" ");
				}
				System.out.println();
			}
		}
		
	}
}
