
public class HighSchoolStudent extends Student {

	int dExam; // 수능까지 남은 기간
	int dGraduate; // 졸업 까지 남은 기간
	
	void Study() {  // Override 
		System.out.println("밤새서 공부");
	}
	void GoToReadingRoom() { 
		System.out.println("독서실 가기");
	}
}
