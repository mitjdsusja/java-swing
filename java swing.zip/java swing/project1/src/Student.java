
public class Student extends Human {
	int grade;
	int numberOfBook;
	
	
	void Study () {
		System.out.println("공부");
	}
	void GoToSchool() {
		System.out.println("학교가기");
	}
}
