
public class Operator {

	public static void main(String[] args) {
		/*
		//1번
		// 사용 class : InputManager, Quadrangle
		
		InputManager mg = new InputManager(); // 입력, 사각형 객체 생성
		Quadrangle rangle = new Quadrangle();
		
		System.out.print("가로 길이 입력 : "); // 가로, 세로 입력
		rangle.hor = mg.getInt();
		System.out.print("세로 길이 입력 : ");
		rangle.ver = mg.getInt();
		
		rangle.area = rangle.getArea(rangle.hor , rangle.ver); // 넓이 계산
		
		System.out.print("사각형의 넓이 = " + rangle.area); // 출력   
		*/
		
		
		/*
		// 2번
		// 사용 class : InputManager, centiConvertor
		
		InputManager mg = new InputManager(); //  변환기, 입력매니저 객체 생성
		centiConvertor conv = new centiConvertor();
		
		System.out.print("변환할 정수 입력 : " ); // 정수 입력후 변환
		conv.a = mg.getInt();
		
		System.out.print(conv.a +"인치 -> " + conv.Convert(conv.a)  + " 센치 "); //출력
		*/
		
		
		/*
		// 3번
		// 사용 class : InputManager, multipleCalculator
		
		multipleCalculator cal = new multipleCalculator();
		
		cal.insertInt(); // 정수 입력
		cal.mCalculate(); // 출력
		*/
		
		
		/*
		// 4번
		// 사용 class : AverageCalculator, InputManager
		
		AverageCalculator cal = new AverageCalculator();
		
		cal.insertInt();                 // 정수 삽입
		cal.avgCalculate();              // 평균 계산
		System.out.println("평균은 " + cal.avg);
		*/
		
		/*
		// 5번
		// 사용 class : Human > Student > HigeSchoolStudent
		
		HighSchoolStudent hss1 = new HighSchoolStudent();
		
		hss1.age = 18;
		hss1.Study();
		hss1.GoToSchool();
		System.out.println("age : " + hss1.age);
		*/
		
		
	}
}
