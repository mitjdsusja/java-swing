
public class Human {
	int age;
	int height;
	String sex;
	
	void Eat() {
		System.out.println("먹기");
	}
	void breathe() {
		System.out.println("숨쉬기");
	}
	void Walk() {
		System.out.println("걷기");
	}
}
