
public class AverageCalculator {
	
	int n = 5 ; // 입력받을 정수의 개수
	double avg = 0; // 평균값 저장할 변수
	int arr[] = new int[n]; 
	
	void insertInt() { // n개의 정수 입력
		
		InputManager mg = new InputManager();
		
		for(int i=0 ; i < n ; i++) {
			System.out.print(i+1 + "번쨰 정수를 입력하시오 : ");
			arr[i] = mg.getInt();
		}
		
	}
	
	void avgCalculate() { // 평균값 계산후 저장

		double temp = 0 ;
		
		for(int i =0 ; i < n ; i++) {
			temp = temp + arr[i];
		}
		avg = temp / n;
	}
}
