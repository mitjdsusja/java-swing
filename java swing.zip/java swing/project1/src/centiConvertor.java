
public class centiConvertor { // 인치 -> 센치 변환
	int a;  // 원래 수 저장
	
	double Convert(int n) { // 인치 -> 센치 변환 메소드
		return n * 2.54 ; 
	}
}
