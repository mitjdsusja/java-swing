
public class Quadrangle {
	int hor  ; 
	int ver  ;
	int area ;
	
	int getArea(int a, int b) { // 넓이 연산 메소드
		int result = 0 ;
		result = a * b;
		return result;
	}
}
