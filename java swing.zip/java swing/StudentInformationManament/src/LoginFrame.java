import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

public class LoginFrame extends JFrame {
	
	// MainFrame
		//		ㄴnorthPanel	
		//			-lb				//
		//			-stateLabel		//로그인 상태 확인 ex)비밀번호가 틀릴시 비밀번호를 확인하시오.
		//		ㄴCenterPanel	(GridLayout)
		//			-idLabel			
		//			-idText			//ID를 입력하는 텍스트필드
		//			-pwLabel
		//			-passwdText		//PW를 입력하는 텍스트필드
		//		ㄴsouthPenel	(GridLayout)
		//			-logInButton	//로그인 버튼 - 아이디 패스워드가 일치한다면 학생관리프로그램 창이 생긴다.
		//			-signupButton	//회원가입 버튼 - 회원가입 팝업이 생긴다.
	
	
	String id;
	String pw;
	
	
	
	JLabel lb = new JLabel("Sign in to S_Manager");	
	JLabel stateLabel = new JLabel("  ");	//로그인 상태 확인 ex)비밀번호가 틀릴시 비밀번호를 확인하시오. (Color : RED) @@@@@@@@@@@@@@
	JLabel idLabel = new JLabel("ID");
	JLabel pwLabel = new JLabel("PW");
	JButton loginButton = new JButton("Sign-In");
	JButton signupButton = new JButton("Sign-Up");
	JPanel northPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	JPanel southPenel = new JPanel();
	JTextField idTextF = new JTextField(20);		//무엇을 입력할지 가이드 추가 (구현필요)
	JTextField pwTextF = new JTextField(20);		//무엇을 입력할지 가이드 추가 (구현필요)
	
	LoginFrame(){
		setTitle("P's StudentManager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JFrame mainLoginFrame = new JFrame();
		Container c = getContentPane();
		
		//메인패널 설정
		c.setLayout(new BorderLayout());
		c.add(northPanel,BorderLayout.NORTH);
		c.add(centerPanel,BorderLayout.CENTER);
		c.add(southPenel,BorderLayout.SOUTH);
		
		//northPanel 컴포넌트 추가 및 설정
		northPanel.setPreferredSize(new Dimension(c.getHeight(),80));
		//northPanel.setBackground(Color.BLUE);
		northPanel.add(lb);
		lb.setLocation(200,50);
		lb.setFont(new Font("Aria",Font.BOLD,30));	
		
		
		//centerPanel 컴포넌트 추가 및 설정
		centerPanel.add(stateLabel);
		stateLabel.setPreferredSize(new Dimension(350,30));
		stateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		centerPanel.add(idLabel);
		idLabel.setPreferredSize(new Dimension(20,30));
		centerPanel.add(idTextF);
		centerPanel.add(pwLabel);
		pwLabel.setPreferredSize(new Dimension(20,30));
		centerPanel.add(pwTextF);
		idTextF.setFont(new Font("Aria",Font.BOLD,15));
		pwTextF.setFont(new Font("Aria",Font.BOLD,15));		
		
		//southPenel 컴포넌트 추가 및 설정
		southPenel.setLayout(new FlowLayout());
		southPenel.setPreferredSize(new Dimension(c.getHeight(),50));
		//southPenel.setBackground(Color.BLACK);
		southPenel.add(loginButton);
		southPenel.add(signupButton);		
		
		loginButton.addActionListener(new MyActionListener());
		signupButton.addActionListener(new MyActionListener());
		
		setSize(350,300);
		setVisible(true);
	}
	
	class MyActionListener implements ActionListener{		//액션 이벤트 리스너 
		public void actionPerformed(ActionEvent e) {		//버튼 액션
			if(e.getSource() == loginButton) {		//로그인 버튼을 눌렀을떄 이벤트
				//SQL에서 아이디에 맞는 패스워드를 가져온후 비교 -맞으면 학생관리매니저 창을 띄움 
				//									-틀리면 stateLabel 로 알림
				
				//텍스트 필드에서 아이디 가져옴 비밀번호 가져옴
				//가져온 값 LoginChecker 한테 넘겨줌 
				//true 값을 반환받으면 학생관리창 띄우기
				String id = idTextF.getText();
				String pw = pwTextF.getText();
				LoginChecker loginChecker = new LoginChecker(id,pw);
				if(loginChecker.loginCheck()) {	
					//학생관리창 생성
					StudentManagerFrame stm = new StudentManagerFrame();
					dispose();
					System.out.println("학생관리 창이 생성되었습니다.");
					
					//로그인창 사라짐 (구현 필요)
					
				}else {
					//아이디 혹은 비밀번호를 확인하라고 알림
					stateLabel.setText("아이디 혹은 비밀번호를 확인해 주세요.");
					System.out.println("아이디 혹은 비밀번호를 확인해 주세요.");
				}
				
//				System.out.println("로그인 버튼 눌림");
				
			}else if(e.getSource() == signupButton) {		//회원가입 버튼을 눌렀을 떄 이벤트
				//회원가입 버튼을 눌렀을 떄 회원가입 팝업을 띄움
//				System.out.println("회원가입 버튼 눌림");
				new SignupFrame();
				
				//회원가입 창이 띄워지면 로그인창 포커스가 안잡히는 기능 (구현 필요)
			}
		}
	}
}
