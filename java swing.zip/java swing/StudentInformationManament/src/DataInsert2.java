import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.StringTokenizer;

public class DataInsert2 {
	
	public static void main(String[] args) {
		String readData; 		//읽은 데이터 임시 저장공간
		StringTokenizer st;		//토크나이저 변수
		File studentFile = new File("C:/students.txt");
		String insertQuery = null;
		
		Connection con = null;
		Statement stmt = null;
		String url = "jdbc:mysql://localhost:55555/university?serverTimezone=Asia/Seoul&useSSL=false";
		String user = "root";
		String passwd = "sungdls200o!";
		
		try {		//SQL connect
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("SQL Connect");//
			
		}catch(Exception e) {
			System.out.println(e.toString());//
		}
		
		
		//학생정보 파일을 한줄씩 읽어 students Table에 저장
		try{
			BufferedReader br = new BufferedReader(new FileReader(studentFile));		//버퍼리더 파일 리더 생성
			while((readData = br.readLine()) != null ){		//파일에서 읽은 데이터가 공백이 아니면 계속 읽음 
				st = new StringTokenizer(readData," ");
				insertQuery = "INSERT INTO students (department, year, sname, grade, snum)   VALUES ( '";
				while(st.hasMoreTokens()) {		//readData한줄 다 끝날 때 까지 반복
					insertQuery += st.nextToken() + "'";
					if(st.hasMoreTokens()) {
						insertQuery += ",'";
					}
				}
				insertQuery += ");";
				stmt.executeUpdate(insertQuery);
			}
			br.close();		//버퍼리더 메모리회수

		}catch(Exception e){ 
			System.out.println(e.getMessage());
	    }
		
		//학과정보를 departments Table에 저장
		try {
			String[] departments = {"컴퓨터공학부","전자공학과", "기계공학과", "건축공학과", "간호학과", "재료공학과", "경영학과", "일어일문학과", "산업경영공학과", "체육학과", "교육학과"};
			
			for(int i=0; i<departments.length ; i++) {
				insertQuery = "INSERT INTO departments (dname) VALUES ('" + departments[i] + "');";
				stmt.executeUpdate(insertQuery);
			}
			
			stmt.close();
			con.close();
		}catch(Exception e) {
			System.out.println(e.toString());
		}

	}

}
