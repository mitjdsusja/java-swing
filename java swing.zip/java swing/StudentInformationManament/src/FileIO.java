import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class FileIO {
	Object[][] dataArr;		//파일 읽은 결과가 저장되는 배열 (데이터 별로 각각 분류되어 저장됨)
	int colCount = 0;				//읽은 데이터의 열의 수
	int rowCount = 0;
	
	//받은 파일을 c단위로 끊어 읽은후 Object 배열에 저장
	FileIO(String data,String c){		//s파일이있는 경로, tokenizer로 자를 단위를 매개변수로 받음
		String readData; 		//읽은 데이터 임시 저장공간
		StringTokenizer st;		//토크나이저 변수
		ArrayList<String> arr = new ArrayList<>();		//파일의 내용을 한줄씩 저장할 배열
		File dataFile = new File(data);
		
		//파일내용을 한줄씩 읽어서 배열에 저장
		try{
			BufferedReader br = new BufferedReader(new FileReader(dataFile));		//버퍼리더 파일 리더 생성
			while((readData = br.readLine()) != null ){		//파일에서 읽은 데이터가 공백이 아니면 계속 읽음 
				arr.add(readData);
				rowCount ++;
			}
			br.close();		//버퍼리더 메모리회수
		}catch(IOException e){ 
			System.out.println(e.getMessage());
	    }
		
		//읽은 데이터의 열의수 저장
		st = new StringTokenizer(arr.get(0),c);
		while(st.hasMoreTokens()) {
			st.nextToken();
			colCount++;
		}
		
		dataArr = new Object[arr.size()][colCount];
		for(int i =0 ; i<arr.size(); i++) {
			st = new StringTokenizer(arr.get(i) , c);
			for(int j =0 ; j<colCount ; j++) {
				String a;
				a = st.nextToken();
				
				dataArr[i][j] = a;
			}
			
		}
	}
}
