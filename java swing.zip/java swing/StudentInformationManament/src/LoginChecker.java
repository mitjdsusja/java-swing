import java.sql.ResultSet;

public class LoginChecker {
	String id;
	String pw;
	boolean loginCheck = false;
	boolean idCheck = false;
	
	DbConnector dc = new DbConnector();
	
	LoginChecker(){
	}
	LoginChecker(String _id){
		id = _id;
		System.out.println("입력된 아이디 : " + id);
	}
	LoginChecker(String _id, String _pw){		//체크할 아이디 비밀번호를 매개변수로 받음
		id = _id;
		pw = _pw;
		
		System.out.println("입력된 아이디 : " + id);
		System.out.println("입력된 비밀번호 : " + pw);
	}
	
	//로그인 가능한 계정 인지 확인 메소드
	//로그인 가능한 계정이면 true, 불가능한 계정이면 false반환
	boolean loginCheck() {
		loginCheck = false;
		
		dc.dbConnect();
		
		String searchQuery;			//"SELECT password FROM user WHERE id='"+uid+"'";
		//SQL에서 아이디 비밀번호 찾음		//"SELECT id FROM user WHERE id = '"+checkingId+"'";
		searchQuery = "SELECT password FROM user WHERE id = '" + id + "'";
		
		try {
			ResultSet result = dc.stmt.executeQuery(searchQuery);//pw가져와서 비교
			if(result.next()) {		//가입된 아이디가 존재한다면
				String d_pw = result.getString("password").toString();//DB에서 해당아이디의 비밀번호 가져옴
				System.out.println("가입된 아이디의 비밀번호 : " + d_pw);
				if(d_pw.equals(pw)) {		//가입된 아이디가 있고, 비밀번호가 일치함
					loginCheck = true;
				}
			}
		}catch(Exception e) {
			System.out.println(e.toString());
			System.out.println("로그인 확인 오류");
		}
		dc.dbClose();
		
		return loginCheck;
	}
	//id중복 확인. 반환값이 true 라면 아이디 중복, false면 중복x
	boolean idCheck() {
		idCheck = false;
		
		dc.dbConnect();
		
		String searchQuery;			
		//SQL에서 아이디 찾음		//"SELECT id FROM students where id = 'id';
		searchQuery = "SELECT password FROM user WHERE id = '" + id + "'";
		
		try {
			ResultSet result = dc.stmt.executeQuery(searchQuery);//pw가져와서 비교
			if(result.next()) {		//가입된 아이디가 존재한다면
				idCheck = true;
			}
		}catch(Exception e) {
			System.out.println(e.toString());
			System.out.println("로그인 확인 오류");
		}
		dc.dbClose();
		
		return idCheck;
	}
}
