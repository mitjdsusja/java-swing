
public class Operator {

	public static void main(String[] args) {
		LoginFrame lf = new LoginFrame();
//		SignupFrame sf = new SignupFrame();
//		StudentManagerFrame sm = new StudentManagerFrame();
//		DbConnector dc = new DbConnector();
//		dc.dbConnect();
//		dc.dbClose();
//		FileIO f = new FileIO("C:/students.txt", " ");
	}

}
