import java.awt.*;
import java.awt.event.*;
import java.sql.Array;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;


public class StudentManagerFrame extends JFrame {
	boolean isCheckUs = false;		//체크박스 선택 확인
	boolean isCheckGs = false;
	int choiceDepartment = -1;
	int numberOfStudent = 0;
	
	JFrame mainFrame;
	
	ArrayList<String> departments = new ArrayList<>();	
	Object[][] students ; 
	
	//공간제어용 컨테이너들.
	JPanel basePanel = new JPanel(new BorderLayout());
	JPanel westPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	//메뉴용
	JMenuBar mb = new JMenuBar();
	JMenu homeMenu = new JMenu("MAIN");
	JMenuItem openMI = new JMenuItem("학생등록");
	JMenuItem newMI = new JMenuItem("학생삭제");
	JMenuItem exitMI = new JMenuItem("종료");
	//웨스트패널상의 컴포넌트들....
	JLabel titleLabel = new JLabel("Select Student Type");
	JCheckBox usCheck = new JCheckBox("학부생");
	JCheckBox gsCheck = new JCheckBox("대학원생");
	JComboBox comboBox;
	JTree tree;
	DefaultMutableTreeNode root;
	DefaultTreeModel treeModel;
	//센터패널상의 컴포넌트들...
	JTable table;
	DefaultTableModel tableModel;
	String columNames[] = {"학과", "학년", "이름", "구분", "학번"};	
	
	//DB
	DbConnector dc = new DbConnector();
//	ResultSet result;		//DB에서 받은 데이터 저장
	
	
	StudentManagerFrame(){
		setTitle("학생정보관리시스템_박성용");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainFrame = new JFrame();
		
		//메뉴추가
		homeMenu.add(openMI);
		homeMenu.add(newMI);
		homeMenu.add(exitMI);
		mb.add(homeMenu);
		setJMenuBar(mb);
		
		exitMI.addActionListener(new MyActionListener());
		
		// 패널 추가 작업
		westPanel.setPreferredSize(new Dimension(160, basePanel.getHeight()));
		setContentPane(basePanel);
		basePanel.add(westPanel, BorderLayout.WEST);
		basePanel.add(centerPanel, BorderLayout.CENTER);
		westPanel.setLayout(new FlowLayout());		
		
		//웨스트패널 컴포넌트 작업
		
		//SQl에서 department 받아와서 배열에 저장
		dc.dbConnect();
		try {
			ResultSet result = dc.getData("SELECT dname FROM departments");
			int i=0;
			while(result.next()) {
//				System.out.println(result.getString("dname").toString());
				departments.add(result.getString("dname").toString());
				i++;
			}
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		dc.dbClose();
		//
		comboBox = new JComboBox(departments.toArray());
		comboBox.setPreferredSize(new Dimension(160, 20));
		titleLabel.setPreferredSize(new Dimension(160, 20));
		tree = new JTree(root);
		tree.setPreferredSize(new Dimension(160, 140));
		
		//리스너 추가
		tree.addTreeSelectionListener(new MyTreeListener());
		usCheck.addItemListener(new MyItemListener());
		gsCheck.addItemListener(new MyItemListener());
		comboBox.addActionListener(new MyActionListener());
		
		
		
		
		westPanel.add(titleLabel);
		westPanel.add(usCheck);
		westPanel.add(gsCheck);
		westPanel.add(comboBox);
		westPanel.add(tree);
		
		//센터패널 작업
		tableModel = new DefaultTableModel(students, columNames);
		table = new JTable(tableModel);
		JScrollPane sp = new JScrollPane(table);
		centerPanel.setLayout(new BorderLayout());
		centerPanel.add(sp, BorderLayout.CENTER);
		
		
		setSize(900, 300);
		setVisible(true);
	}
	
	//Tree 이벤트 리스너
	class MyTreeListener implements TreeSelectionListener{
		public void valueChanged(TreeSelectionEvent e) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
			if(node == null) return;	//node가 null일때 node.getUserObject()오류 방지
			System.out.println((String)node.getUserObject());
			int year = 0;
			switch((String)node.getUserObject()) {
			
			case "4학년":	year++;
			case "3학년":	year++;
			case "2학년":	year++;
			case "1학년":	year++;
				//DB 에서 학생정보 가져옴
				dc.dbConnect();
				try {
					ResultSet result;
//					System.out.println(" 학생수 저장 ");
					// "SELECT * FROM student where department = '학과' , year = '학년';
					result = dc.getData("SELECT * from students where department = '" +departments.get(choiceDepartment) + "' AND year = " +year+ ";");
					numberOfStudent =0;
					while(result.next()) {		//학생수 저장
						numberOfStudent++ ;
					}
					
					//student 배열에 학생데이터 저장
					students = new Object[numberOfStudent][columNames.length];
					System.out.println("학생 정보 가져옴");
					result = dc.getData("SELECT * from students where department = '" +departments.get(choiceDepartment) + "' AND year = " +year+ ";");
					int i=0;
					while(result.next()) {
						students[i][0] = result.getString("department").toString();
						students[i][1] = result.getString("year").toString();
						students[i][2] = result.getString("sname").toString();
						students[i][3] = result.getString("grade").toString();
						students[i][4] = result.getString("snum").toString();
						i++;
					}
//					//students 배열 확인
//					for(int j=0 ; j<numberOfStudent ; j++) {
//						for(int k = 0; k<5;k++) {
//							System.out.print(students[j][k] + " ");
//						}
//						System.out.println();
//						
//					}
					
					//테이블 받아온 데이터로 재설정
					tableModel.setDataVector(students, columNames);
					
					
				}catch(Exception _e) {
					System.out.println(_e.toString());
				}
				break;
			}
		}
	}
	
	class MyItemListener implements ItemListener{		
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange() == ItemEvent.SELECTED) {		//체크박스 체크시 
				if(e.getItem() == usCheck) isCheckUs = true;
				else if(e.getItem() == gsCheck) isCheckGs = true;
			}
			else if (e.getStateChange() == ItemEvent.DESELECTED) {
				if(e.getItem() == usCheck) isCheckUs = false;
				else if(e.getItem() == gsCheck) isCheckGs = false;
			}
			Filtering();
		}
	}
	
	//콤보박스 액션 리스너
	class MyActionListener implements ActionListener{	
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == comboBox) {
				JComboBox ccc = (JComboBox)e.getSource();
				choiceDepartment = ccc.getSelectedIndex();
				root = new DefaultMutableTreeNode(departments.get(choiceDepartment));			//학과가 아닌 콤보박스에서 선택한 학과로 변환 (미구현)
				
				//학과콤보박스 선택시 해당 학과 트리에 표시
				for(int i = 1; i<=4;i++ ) {
					DefaultMutableTreeNode node =  new DefaultMutableTreeNode(i + "학년");
					root.add(node);
					treeModel = (DefaultTreeModel)tree.getModel();
					treeModel.setRoot(root);
				}
			}
			else if(e.getSource() == exitMI) {		//종료버튼 
				System.out.println("EXIT 클릭");
				dispose();
				
			}
			Filtering();
		}
	}
	
	
	
		//학과 필터링 후, 학부생,대학원생 필터링
		//학부,대학원 둘다 체크시 학부,대학원생 둘다 출력
		//학부,대학원 둘중 하나 체크시 선택한 구분 출력
		//학부,대학원 아무것도 체크안할시 출력x 
	public void Filtering() {			
		TableRowSorter<TableModel> sorter  = new TableRowSorter<TableModel>(tableModel);		//http://cris.joongbu.ac.kr/course/2018-1/jcp/api/javax/swing/RowFilter.html
		ArrayList<RowFilter<Object, Object>> filters = new ArrayList<RowFilter<Object, Object>>(2);
		table.setRowSorter(sorter);
		RowFilter<TableModel, Object> rf = null;
			
		if(choiceDepartment != -1) {		//프로그램 실행 직후(ChoiceDepartment !=-1)일때 학과 전체 출력 
			filters.add(RowFilter.regexFilter(departments.get(choiceDepartment), 0));		//학과 필터링
		}
			
		if(isCheckUs == true && isCheckGs == true) {		//체크박스 학부생, 대학원생 둘다 체크시 
			filters.add(RowFilter.regexFilter("", 3));		//학부생, 대학원생필터링
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == true && isCheckGs == false) {		//
			filters.add(RowFilter.regexFilter("학부생", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == false && isCheckGs == true) {		//
			filters.add(RowFilter.regexFilter("대학원생", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
		else if(isCheckUs == false && isCheckGs == false) {		//
			filters.add(RowFilter.regexFilter("@@@@@@@", 3));
			rf = RowFilter.andFilter(filters);
			sorter.setRowFilter(rf);
		}
			
	}

	
}
