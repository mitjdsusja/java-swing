import java.sql.*;

public class DbConnector {
	Connection con = null;
	Statement stmt = null;
	String url = "jdbc:mysql://localhost:55555/university?serverTimezone=Asia/Seoul&useSSL=false";
	String user = "root";
	String passwd = "sungdls200o!";

	void dbConnect(){
		try {		//SQL connect
			con = DriverManager.getConnection(url,user,passwd);
			stmt = con.createStatement();
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("SQL Connect");//
			
		}catch(Exception e) {
			System.out.println(e.toString());//
		}
	}
	
	//DB에서 데이터 읽어옴
	ResultSet getData(String Query) {
		ResultSet result = null;
		System.out.println("쿼리" + Query);
		try {
			result = stmt.executeQuery(Query);
		}catch(Exception e){
			System.out.println("쿼리문 실행 오류");
		}
		
		return result;
	}
	
	
	void dbClose() {
		try {
			stmt.close();
			con.close();
			System.out.println("SQL Close");
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
}
